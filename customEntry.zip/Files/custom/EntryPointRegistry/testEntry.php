<?php

  $entry_point_registry['testEntryPoint'] = array(
    'file' => 'custom/myentrypoints/testEntry.php',
    'auth' => true
  );
